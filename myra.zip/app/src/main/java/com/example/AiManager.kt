package com.example

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object AiManager {
    const val OPENAI_API_KEY = "sk-TIjVHTw8cnElb5E6pi0WvIH7aROcScLTkZKjXGgnJbTkQfv1"

    private val client by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    fun getReplySync(userMsg: String): String {
        try {
            val json = JSONObject()
            json.put("model", "gpt-4o-mini")

            val messages = JSONArray()
            val sys = JSONObject()
            sys.put("role", "system")
            sys.put("content", "You are MYRA, 22yo respectful female assistant. Call user Sir/Boss/Vaiya only. Never use jaan/baby/sona. Reply in same language as user, Bengali if user speaks Bengali. Keep reply short max 2 lines.")

            val usr = JSONObject()
            usr.put("role", "user")
            usr.put("content", userMsg)

            messages.put(sys)
            messages.put(usr)
            json.put("messages", messages)

            val body = json.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                .addHeader("Authorization", "Bearer $OPENAI_API_KEY")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build()

            val resp = client.newCall(request).execute()
            val respStr = resp.body?.string() ?: return "Ji Sir bolun."
            val obj = JSONObject(respStr)

            if (obj.has("choices")) {
                val choices = obj.getJSONArray("choices")
                if (choices.length() > 0) {
                    return choices.getJSONObject(0).getJSONObject("message").getString("content").trim()
                }
            }
            if (obj.has("error")) {
                val errObj = obj.getJSONObject("error")
                val msg = errObj.optString("message", "API error")
                return "Sir, brain connect korte somoshya hocche ($msg)."
            }
            return "Ji Sir bolun, ami shunchi."
        } catch (e: Exception) {
            return "Ji Sir bolun, ami shunchi. Network check korun."
        }
    }

    suspend fun getReply(userMsg: String): String = withContext(Dispatchers.IO) {
        getReplySync(userMsg)
    }
}
