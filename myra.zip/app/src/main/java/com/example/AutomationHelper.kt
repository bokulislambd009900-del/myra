package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.util.Log
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AutomationHelper {
    private const val TAG = "AutomationHelper"

    val appMap: Map<String, String> = mapOf(
        "play store" to "com.android.vending",
        "youtube" to "com.google.android.youtube",
        "facebook" to "com.facebook.katana",
        "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "maps" to "com.google.android.apps.maps",
        "gmail" to "com.google.android.gm",
        "chrome" to "com.android.chrome",
        "camera" to "com.android.camera2",
        "settings" to "com.android.settings",
        "gallery" to "com.google.android.apps.photos",
        "photos" to "com.google.android.apps.photos",
        "messenger" to "com.facebook.orca",
        "dialer" to "com.google.android.dialer",
        "phone" to "com.google.android.dialer"
    )

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = MessageSender.MYRA,
                text = "MYRA Jarvis is online Sir. Brain (GPT-4o-mini), WhatsApp, Calls, and SOS active."
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isTorchOn = MutableStateFlow(false)
    val isTorchOn: StateFlow<Boolean> = _isTorchOn.asStateFlow()

    fun addMessage(sender: MessageSender, text: String) {
        val updated = _chatMessages.value.toMutableList().apply {
            add(ChatMessage(sender = sender, text = text))
        }
        _chatMessages.value = updated
    }

    fun openApp(context: Context, name: String): String {
        val cleanName = name.lowercase(Locale.ROOT).trim()
        Log.d(TAG, "Requested to open app: $cleanName")

        var targetPkg: String? = null
        for ((key, pkg) in appMap) {
            if (cleanName.contains(key)) {
                targetPkg = pkg
                break
            }
        }

        val pm = context.packageManager
        if (targetPkg == null) {
            try {
                val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                for (app in installed) {
                    val label = pm.getApplicationLabel(app).toString().lowercase(Locale.ROOT)
                    if (cleanName.contains(label) || label.contains(cleanName)) {
                        targetPkg = app.packageName
                        break
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error querying packages: ${e.message}")
            }
        }

        if (targetPkg != null) {
            val launchIntent = pm.getLaunchIntentForPackage(targetPkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return "Sir, $cleanName khule dichhi."
            } else {
                return try {
                    val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$targetPkg")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(marketIntent)
                    "App ti install kora nei, Play Store e dekhano hocche."
                } catch (e: Exception) {
                    "Sir, $cleanName open kora sombhob hochhe na."
                }
            }
        }

        return "Sir, $cleanName app ti khuje paini."
    }

    fun listApps(context: Context): String {
        return try {
            val pm = context.packageManager
            val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val launchableNames = mutableListOf<String>()

            for (app in installed) {
                if (pm.getLaunchIntentForPackage(app.packageName) != null) {
                    val label = pm.getApplicationLabel(app).toString()
                    if (label.isNotBlank() && !launchableNames.contains(label)) {
                        launchableNames.add(label)
                    }
                }
                if (launchableNames.size >= 30) break
            }

            val appListStr = launchableNames.joinToString(", ")
            "Sir, apnar phone e egulo app ache: $appListStr."
        } catch (e: Exception) {
            Log.e(TAG, "Error listing apps", e)
            "Sir, app list porte samanno shomoshya hocche."
        }
    }

    fun getBattery(context: Context): Int {
        return try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (e: Exception) {
            Log.e(TAG, "Error getting battery capacity", e)
            -1
        }
    }

    fun toggleTorch(context: Context, on: Boolean): String {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var flashCameraId: String? = null
            for (id in cameraManager.cameraIdList) {
                val chars = cameraManager.getCameraCharacteristics(id)
                val flashAvailable = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                if (flashAvailable && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    flashCameraId = id
                    break
                }
            }
            if (flashCameraId == null && cameraManager.cameraIdList.isNotEmpty()) {
                flashCameraId = cameraManager.cameraIdList[0]
            }

            if (flashCameraId != null) {
                cameraManager.setTorchMode(flashCameraId, on)
                _isTorchOn.value = on
                if (on) "Sir, flashlight jwalano hoyeche." else "Sir, flashlight bondho kora hoyeche."
            } else {
                "Sir, flashlight khuje paini."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Torch toggle error: ${e.message}")
            "Sir, flashlight control korte somoshya hoyeche."
        }
    }

    // --- PART 2 NEW FUNCTIONS ---

    fun getPhoneNumber(ctx: Context, name: String): String? {
        val cr = ctx.contentResolver
        val cur = cr.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            null,
            ContactsContract.Contacts.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"),
            null
        )
        var number: String? = null
        if (cur != null) {
            if (cur.moveToFirst()) {
                number = cur.getString(cur.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER))
            }
            cur.close()
        }
        return number?.replace(" ", "")?.replace("-", "")?.replace("(", "")?.replace(")", "")
    }

    fun sendWhatsApp(ctx: Context, contact: String, msg: String) {
        val phone = getPhoneNumber(ctx, contact)
        if (phone == null) {
            val reply = "Sir, $contact er number pelam na"
            TTSHelper.speak(reply)
            addMessage(MessageSender.MYRA, reply)
            return
        }

        // Clean leading zero if present to format international BD 880
        val cleanPhone = if (phone.startsWith("+88")) {
            phone.substring(1)
        } else if (phone.startsWith("88")) {
            phone
        } else if (phone.startsWith("0")) {
            "88$phone"
        } else {
            "88$phone"
        }

        try {
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=" + URLEncoder.encode(msg, "UTF-8"))
            val i = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(i)

            val statusMsg = "Sir, $contact ke WhatsApp e message pathano hocche..."
            TTSHelper.speak(statusMsg)
            addMessage(MessageSender.MYRA, statusMsg)

            Handler(Looper.getMainLooper()).postDelayed({
                MyAccessibilityService.instance?.clickSend()
                val doneMsg = "Ji Sir, $contact ke message dewa hoye geche"
                TTSHelper.speak(doneMsg)
                addMessage(MessageSender.MYRA, doneMsg)
            }, 3000)
        } catch (e: Exception) {
            Log.e(TAG, "WhatsApp error: ${e.message}")
            val errMsg = "Sir, WhatsApp message pathate somoshya hoyeche."
            TTSHelper.speak(errMsg)
            addMessage(MessageSender.MYRA, errMsg)
        }
    }

    fun makeCall(ctx: Context, contact: String) {
        val phone = getPhoneNumber(ctx, contact)
        if (phone == null) {
            val reply = "Sir, $contact er number khuje paini."
            TTSHelper.speak(reply)
            addMessage(MessageSender.MYRA, reply)
            return
        }
        try {
            val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phone")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(i)
            val reply = "Sir, $contact ke call korchi."
            TTSHelper.speak(reply)
            addMessage(MessageSender.MYRA, reply)
        } catch (e: Exception) {
            Log.e(TAG, "Call error: ${e.message}")
            // Fallback to DIAL intent if CALL_PHONE is not active
            try {
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ctx.startActivity(dialIntent)
            } catch (ex: Exception) {
                val errMsg = "Sir, call korte somoshya hoyeche."
                TTSHelper.speak(errMsg)
                addMessage(MessageSender.MYRA, errMsg)
            }
        }
    }

    fun setAlarm(ctx: Context, text: String) {
        val regex = Regex("(\\d{1,2})(?::(\\d{2}))?")
        val m = regex.find(text)
        var h = 6
        var min = 0
        if (m != null) {
            h = m.groupValues[1].toInt()
            if (m.groupValues[2].isNotEmpty()) {
                min = m.groupValues[2].toInt()
            }
        }
        try {
            val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, h)
                putExtra(AlarmClock.EXTRA_MINUTES, min)
                putExtra(AlarmClock.EXTRA_MESSAGE, "MYRA Alarm")
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(i)
            val reply = "Sir, $h ta ${if (min > 0) "$min baje" else ""} tay alarm set kora hoyeche."
            TTSHelper.speak(reply)
            addMessage(MessageSender.MYRA, reply)
        } catch (e: Exception) {
            Log.e(TAG, "Alarm error: ${e.message}")
            val errMsg = "Sir, alarm set korte somoshya hoyeche."
            TTSHelper.speak(errMsg)
            addMessage(MessageSender.MYRA, errMsg)
        }
    }

    fun readScreen() {
        val txt = MyAccessibilityService.instance?.getAllScreenText()
        val textToSpeak = if (!txt.isNullOrBlank()) {
            txt.take(500)
        } else {
            "Screen e kichu pelam na, ba Accessibility service on kora nei Sir."
        }
        TTSHelper.speak(textToSpeak)
        addMessage(MessageSender.MYRA, "Screen Text: $textToSpeak")
    }

    fun getLocation(ctx: Context) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            val errMsg = "Sir, location permission on kora nei."
            TTSHelper.speak(errMsg)
            addMessage(MessageSender.MYRA, errMsg)
            return
        }

        try {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(ctx)
            fusedLocationClient.lastLocation.addOnSuccessListener { loc ->
                if (loc != null) {
                    val lat = loc.latitude
                    val lng = loc.longitude
                    val mapsUrl = "https://maps.google.com/?q=$lat,$lng"
                    val reply = "Sir, apnar location: Latitude $lat, Longitude $lng. Google Maps link ready."
                    TTSHelper.speak("Sir, apnar current location pelam. Maps link dewa holo.")
                    addMessage(MessageSender.MYRA, "$reply\n$mapsUrl")
                } else {
                    val reply = "Sir, GPS theke ekhon location pawa jacche na."
                    TTSHelper.speak(reply)
                    addMessage(MessageSender.MYRA, reply)
                }
            }.addOnFailureListener {
                val errMsg = "Sir, location read korte somoshya hocche."
                TTSHelper.speak(errMsg)
                addMessage(MessageSender.MYRA, errMsg)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Location error: ${e.message}")
            val errMsg = "Sir, location pawa jacche na."
            TTSHelper.speak(errMsg)
            addMessage(MessageSender.MYRA, errMsg)
        }
    }

    fun sendEmergencySos(ctx: Context) {
        val sosMsg = "EMERGENCY SOS: Sir is in danger! Assistance requested immediately."
        TTSHelper.speak("EMERGENCY SOS ACTIVATED. Sir, help is being notified.")
        addMessage(MessageSender.MYRA, sosMsg)

        // Fetch location and prepare SOS message
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            val fusedClient = LocationServices.getFusedLocationProviderClient(ctx)
            fusedClient.lastLocation.addOnSuccessListener { loc ->
                val locationUrl = if (loc != null) "https://maps.google.com/?q=${loc.latitude},${loc.longitude}" else "Location unavailable"
                val detailedSos = "SOS Alert! Sir needs emergency help. Location: $locationUrl"
                addMessage(MessageSender.MYRA, detailedSos)
            }
        }

        // Open dialer with 999 or emergency
        try {
            val emergencyCall = Intent(Intent.ACTION_DIAL, Uri.parse("tel:999")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(emergencyCall)
        } catch (e: Exception) {
            Log.e(TAG, "SOS call error: ${e.message}")
        }
    }

    fun processCommandPart1(context: Context, rawCommand: String): String {
        return processCommand(context, rawCommand)
    }

    fun processCommand(context: Context, rawCommand: String): String {
        val command = rawCommand.lowercase(Locale.ROOT).trim()
        Log.d(TAG, "Processing command Part 2: $command")

        // Record user speech in chat
        addMessage(MessageSender.USER, rawCommand)

        // 1. WhatsApp automation
        if (command.contains("whatsapp")) {
            // Pattern: whatsapp e [contact] ke bolo [msg] or whatsapp e [contact] [msg]
            var contact = ""
            var message = "Hello"

            if (command.contains("whatsapp e") && command.contains("ke bolo")) {
                val afterWe = command.substringAfter("whatsapp e").trim()
                contact = afterWe.substringBefore("ke bolo").trim()
                message = afterWe.substringAfter("ke bolo").trim()
            } else if (command.contains("ke bolo")) {
                contact = command.substringBefore("ke bolo").replace("whatsapp", "").trim()
                message = command.substringAfter("ke bolo").trim()
            } else if (command.contains("bolo")) {
                contact = command.substringBefore("bolo").replace("whatsapp", "").replace("e", "").trim()
                message = command.substringAfter("bolo").trim()
            } else {
                // simple whatsapp open or contact
                val parts = command.replace("whatsapp", "").trim().split(" ")
                if (parts.isNotEmpty() && parts[0].isNotBlank()) {
                    contact = parts[0]
                    message = if (parts.size > 1) parts.drop(1).joinToString(" ") else "Hello"
                }
            }

            if (contact.isNotBlank()) {
                sendWhatsApp(context, contact, if (message.isBlank()) "Hello" else message)
                return "Sir, WhatsApp message pathano hocche."
            } else {
                openApp(context, "whatsapp")
                return "Sir, WhatsApp open kora hoyeche."
            }
        }

        // 2. Call automation
        if (command.startsWith("call") || command.contains("call koro") || command.contains("phone koro") || command.contains("ফোন কর")) {
            val contact = command
                .replace("call koro", "")
                .replace("call", "")
                .replace("phone koro", "")
                .replace("ke", "")
                .trim()
            if (contact.isNotBlank()) {
                makeCall(context, contact)
                return "Sir, $contact ke call korchi."
            }
        }

        // 3. Alarm automation
        if (command.contains("alarm") || command.contains("অ্যালার্ম")) {
            setAlarm(context, command)
            return "Sir, alarm process kora holo."
        }

        // 4. Screen Reading
        if (command.contains("screen poro") || command.contains("read screen") || command.contains("স্ক্রিন পড়")) {
            readScreen()
            return "Sir, screen porchi."
        }

        // 5. Location
        if (command.contains("kothay achi") || command.contains("amar location") || command.contains("where am i") || command.contains("location")) {
            getLocation(context)
            return "Sir, apnar location check korchi."
        }

        // 6. SOS Emergency
        if (command.contains("sos") || command.contains("emergency") || command.contains("bachao") || command.contains("বাঁচাও")) {
            sendEmergencySos(context)
            return "Emergency SOS activated!"
        }

        // 7. Battery commands
        if (command.contains("battery") || command.contains("charge")) {
            val batteryLevel = getBattery(context)
            val reply = if (batteryLevel >= 0) {
                "Sir, apnar phoner battery $batteryLevel percent ache."
            } else {
                "Sir, battery percentage jaana jacche na."
            }
            TTSHelper.speak(reply)
            addMessage(MessageSender.MYRA, reply)
            return reply
        }

        // 8. Torch commands
        if (command.contains("torch jalao") || command.contains("torch on") ||
            command.contains("flashlight on") || command.contains("light on") ||
            command.contains("torch chalu")) {
            val reply = toggleTorch(context, true)
            TTSHelper.speak(reply)
            addMessage(MessageSender.MYRA, reply)
            return reply
        }

        if (command.contains("torch bondho") || command.contains("torch off") ||
            command.contains("flashlight off") || command.contains("light bondho") ||
            command.contains("torch nibhao")) {
            val reply = toggleTorch(context, false)
            TTSHelper.speak(reply)
            addMessage(MessageSender.MYRA, reply)
            return reply
        }

        // 9. List Apps
        if (command.contains("ki ki app") || command.contains("apps ache") ||
            command.contains("list apps") || command.contains("সব অ্যাপ") ||
            command.contains("installed apps")) {
            val reply = listApps(context)
            TTSHelper.speak(reply)
            addMessage(MessageSender.MYRA, reply)
            return reply
        }

        // 10. Open App commands ("kholo", "open", "chalu koro")
        if (command.contains("kholo") || command.contains("open") ||
            command.contains("chalu") || command.contains("চালু") ||
            command.contains("খোল")) {
            val cleaned = command
                .replace("kholo", "")
                .replace("open", "")
                .replace("chalu koro", "")
                .replace("chalu", "")
                .replace("app", "")
                .replace("ta", "")
                .replace("ti", "")
                .trim()
            val reply = openApp(context, cleaned)
            TTSHelper.speak(reply)
            addMessage(MessageSender.MYRA, reply)
            return reply
        }

        // 11. Time & Date
        if (command.contains("shomoy") || command.contains("time") || command.contains("koita baje")) {
            val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            val reply = "Sir, ekhon shomoy $timeStr."
            TTSHelper.speak(reply)
            addMessage(MessageSender.MYRA, reply)
            return reply
        }

        if (command.contains("tarikh") || command.contains("date") || command.contains("din")) {
            val dateStr = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(Date())
            val reply = "Sir, ajker tarikh $dateStr."
            TTSHelper.speak(reply)
            addMessage(MessageSender.MYRA, reply)
            return reply
        }

        // 12. Direct app map match
        for (appKey in appMap.keys) {
            if (command == appKey || command == "open $appKey" || command == "$appKey kholo") {
                val reply = openApp(context, appKey)
                TTSHelper.speak(reply)
                addMessage(MessageSender.MYRA, reply)
                return reply
            }
        }

        // 13. FALLBACK TO AI BRAIN (GPT-4o-mini via AiManager)
        CoroutineScope(Dispatchers.IO).launch {
            val aiReply = AiManager.getReplySync(rawCommand)
            withContext(Dispatchers.Main) {
                addMessage(MessageSender.MYRA, aiReply)
                TTSHelper.speak(aiReply)
            }
        }

        return "Sir, thinking..."
    }
}
