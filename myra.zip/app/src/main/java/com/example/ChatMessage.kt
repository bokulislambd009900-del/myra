package com.example

import java.util.UUID

enum class MessageSender {
    USER,
    MYRA
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)
