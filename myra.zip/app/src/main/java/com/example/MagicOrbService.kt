package com.example

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

class MagicOrbService : Service() {

    companion object {
        private const val TAG = "MagicOrbService"
        private val _isOrbActive = MutableStateFlow(false)
        val isOrbActive: StateFlow<Boolean> = _isOrbActive.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, MagicOrbService::class.java)
            context.startService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, MagicOrbService::class.java)
            context.stopService(intent)
        }
    }

    private var windowManager: WindowManager? = null
    private var overlayContainer: FrameLayout? = null
    private var orbImageView: ImageView? = null
    private var pulseAnimator: ObjectAnimator? = null
    private lateinit var layoutParams: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Log.w(TAG, "Cannot start MagicOrbService without SYSTEM_ALERT_WINDOW permission")
            stopSelf()
            return
        }

        try {
            setupFloatingOrb()
            _isOrbActive.value = true
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up floating orb: ${e.message}", e)
            stopSelf()
        }
    }

    private fun dpToPx(dp: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp,
            resources.displayMetrics
        ).toInt()
    }

    private fun setupFloatingOrb() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val orbSizePx = dpToPx(130f)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            orbSizePx,
            orbSizePx,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 260
        }

        // Outer container
        overlayContainer = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }

        // Inner glowing orb ImageView
        orbImageView = ImageView(this).apply {
            val orbRadius = dpToPx(130f) / 2f
            val gradient = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                gradientType = GradientDrawable.RADIAL_GRADIENT
                colors = intArrayOf(
                    Color.parseColor("#00E5FF"), // Cyan
                    Color.parseColor("#7C4DFF")  // Purple
                )
                gradientRadius = orbRadius
            }
            background = gradient
            elevation = 20f

            val imagePadding = dpToPx(28f)
            setPadding(imagePadding, imagePadding, imagePadding, imagePadding)
            setImageResource(android.R.drawable.ic_btn_speak_now)
            setColorFilter(Color.WHITE)
        }

        val frameParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        overlayContainer?.addView(orbImageView, frameParams)

        // Pulsing animation as requested
        val pvhAlpha = PropertyValuesHolder.ofFloat("alpha", 0.35f, 1f, 0.35f)
        val pvhScaleX = PropertyValuesHolder.ofFloat("scaleX", 0.9f, 1.15f, 0.9f)
        val pvhScaleY = PropertyValuesHolder.ofFloat("scaleY", 0.9f, 1.15f, 0.9f)

        pulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
            orbImageView,
            pvhAlpha,
            pvhScaleX,
            pvhScaleY
        ).apply {
            duration = 1500
            repeatCount = ObjectAnimator.INFINITE
            start()
        }

        // Draggable OnTouchListener
        overlayContainer?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var touchStartTime = 0L
            private var isClick = false

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                val wm = windowManager ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = layoutParams.x
                        initialY = layoutParams.y
                        touchX = event.rawX
                        touchY = event.rawY
                        touchStartTime = System.currentTimeMillis()
                        isClick = true
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()

                        if (abs(dx) > 10 || abs(dy) > 10) {
                            isClick = false
                        }

                        layoutParams.x = initialX + dx
                        layoutParams.y = initialY + dy

                        try {
                            wm.updateViewLayout(overlayContainer, layoutParams)
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed to update orb position: ${e.message}")
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val duration = System.currentTimeMillis() - touchStartTime
                        if (isClick && duration < 300) {
                            onOrbClicked()
                        }
                        return true
                    }
                }
                return false
            }
        })

        windowManager?.addView(overlayContainer, layoutParams)
    }

    private fun onOrbClicked() {
        Log.d(TAG, "Magic Orb clicked")
        TTSHelper.speak("MYRA is ready, Sir. How can I help you?")

        // Also launch or bring MainActivity to front
        val appIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        startActivity(appIntent)
    }

    override fun onDestroy() {
        super.onDestroy()
        pulseAnimator?.cancel()
        pulseAnimator = null

        overlayContainer?.let { container ->
            try {
                if (container.isAttachedToWindow) {
                    windowManager?.removeView(container)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error removing overlay container: ${e.message}")
            }
        }
        overlayContainer = null
        orbImageView = null
        _isOrbActive.value = false
        Log.d(TAG, "MagicOrbService destroyed")
    }
}
