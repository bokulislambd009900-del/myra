package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.theme.JarvisBlack
import com.example.ui.theme.JarvisCardBg
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisDarkSurface
import com.example.ui.theme.JarvisGreen
import com.example.ui.theme.JarvisMuted
import com.example.ui.theme.JarvisPurple
import com.example.ui.theme.JarvisRed
import com.example.ui.theme.JarvisTextCyan
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize Text-to-Speech Engine with Female Voice
        TTSHelper.init(this)

        setContent {
            MyApplicationTheme {
                MyraMainScreen(
                    onCheckOverlayPermission = { checkOverlayPermission() },
                    onRequestOverlayPermission = { requestOverlayPermission() },
                    onStartOrb = { startOrbService() },
                    onStopOrb = { stopOrbService() },
                    onStartSpeech = { startSpeechService() },
                    onStopSpeech = { stopSpeechService() }
                )
            }
        }
    }

    private fun checkOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun startOrbService() {
        if (checkOverlayPermission()) {
            MagicOrbService.start(this)
        } else {
            requestOverlayPermission()
        }
    }

    private fun stopOrbService() {
        MagicOrbService.stop(this)
    }

    private fun startSpeechService() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            SpeechService.start(this)
        }
    }

    private fun stopSpeechService() {
        SpeechService.stop(this)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyraMainScreen(
    onCheckOverlayPermission: () -> Boolean,
    onRequestOverlayPermission: () -> Unit,
    onStartOrb: () -> Unit,
    onStopOrb: () -> Unit,
    onStartSpeech: () -> Unit,
    onStopSpeech: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val chatMessages by AutomationHelper.chatMessages.collectAsState()
    val isSpeaking by TTSHelper.isSpeaking.collectAsState()
    val isTorchOn by AutomationHelper.isTorchOn.collectAsState()
    val isOrbActive by MagicOrbService.isOrbActive.collectAsState()
    val isSpeechRunning by SpeechService.isServiceRunning.collectAsState()
    val isMicListening by SpeechService.isListening.collectAsState()

    var textInput by remember { mutableStateOf("") }
    var hasOverlayPermission by remember { mutableStateOf(onCheckOverlayPermission()) }

    // Multi-permission launcher
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val audioGranted = result[Manifest.permission.RECORD_AUDIO] ?: false
        if (audioGranted) {
            onStartSpeech()
        }
    }

    // Direct Speech Recognizer Activity Launcher for one-shot mic tap
    val speechInputLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { activityResult ->
        if (activityResult.resultCode == android.app.Activity.RESULT_OK) {
            val results = activityResult.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!results.isNullOrEmpty()) {
                val recognized = results[0]
                AutomationHelper.processCommand(context, recognized)
            }
        }
    }

    // Request permissions on first composition
    LaunchedEffect(Unit) {
        val permissions = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionsLauncher.launch(permissions.toTypedArray())

        if (hasOverlayPermission) {
            onStartOrb()
        }
    }

    // Auto-scroll chat to latest message
    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    // Pulsing animation for Mic / Ball
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = JarvisBlack,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Glowing status indicator dot
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(if (isSpeechRunning || isOrbActive) JarvisCyan else JarvisMuted)
                        )
                        Text(
                            text = "MYRA",
                            fontWeight = FontWeight.Black,
                            fontSize = 22.sp,
                            letterSpacing = 2.sp,
                            color = JarvisCyan
                        )
                        Text(
                            text = "JARVIS AI",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = JarvisPurple,
                            modifier = Modifier
                                .border(1.dp, JarvisPurple, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                },
                actions = {
                    if (isSpeaking) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Speaking",
                            tint = JarvisCyan,
                            modifier = Modifier
                                .padding(end = 12.dp)
                                .scale(pulseScale)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = JarvisDarkSurface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(JarvisBlack)
        ) {
            // Overlay Permission Warning Banner if missing
            if (!hasOverlayPermission) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("overlay_permission_banner"),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2A1515)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Floating Magic Orb Permission Required",
                                color = JarvisRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Allow display over other apps to see floating ball",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 11.sp
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = JarvisCyan,
                            modifier = Modifier.clickable {
                                onRequestOverlayPermission()
                                hasOverlayPermission = onCheckOverlayPermission()
                            }
                        ) {
                            Text(
                                text = "ALLOW",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Quick Status Controls Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = JarvisCardBg),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Magic Orb Toggle
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = "Magic Orb",
                            tint = if (isOrbActive) JarvisCyan else JarvisMuted,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = "Magic Orb",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = if (isOrbActive) "Floating Active" else "Inactive",
                                fontSize = 10.sp,
                                color = if (isOrbActive) JarvisCyan else JarvisMuted
                            )
                        }
                        Switch(
                            checked = isOrbActive,
                            onCheckedChange = { checked ->
                                if (checked) onStartOrb() else onStopOrb()
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = JarvisCyan,
                                checkedTrackColor = JarvisDarkSurface
                            ),
                            modifier = Modifier.scale(0.8f)
                        )
                    }

                    // Continuous Speech Service Toggle
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isSpeechRunning) Icons.Default.Mic else Icons.Default.MicOff,
                            contentDescription = "Voice Listener",
                            tint = if (isSpeechRunning) JarvisCyan else JarvisMuted,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = "Background Mic",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = if (isSpeechRunning) "Listening" else "Off",
                                fontSize = 10.sp,
                                color = if (isSpeechRunning) JarvisGreen else JarvisMuted
                            )
                        }
                        Switch(
                            checked = isSpeechRunning,
                            onCheckedChange = { checked ->
                                if (checked) onStartSpeech() else onStopSpeech()
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = JarvisGreen,
                                checkedTrackColor = JarvisDarkSurface
                            ),
                            modifier = Modifier.scale(0.8f)
                        )
                    }
                }
            }

            // Command Chips Row with Part 2 Features
            val chips = listOf(
                "Tumi ke? Ki ki korte paro?" to "Ask AI Brain",
                "Kothay achi" to "📍 Location",
                "Screen poro" to "📜 Read Screen",
                "WhatsApp e Sakib ke bolo kemon acho" to "💬 WhatsApp",
                "Call Sakib" to "📞 Call",
                "Alarm dao 7 tay" to "⏰ Set Alarm",
                "Emergency SOS" to "🚨 SOS",
                "Battery koto" to "🔋 Battery",
                "Torch jalao" to "🔦 Torch",
                "Ki ki app ache" to "📱 Apps",
                "YouTube kholo" to "▶️ YouTube"
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                chips.forEach { (command, label) ->
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = JarvisDarkSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, JarvisCyan.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .clickable {
                                AutomationHelper.processCommand(context, command)
                            }
                            .testTag("chip_${label.lowercase(Locale.ROOT).replace(" ", "_")}")
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = JarvisCyan,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Chat Feed
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(chatMessages, key = { it.id }) { message ->
                    ChatMessageItem(message)
                }
            }

            // Bottom Input & Mic Bar
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
                shape = RoundedCornerShape(24.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = {
                            Text(
                                text = "Ask MYRA... (e.g. YouTube kholo)",
                                color = JarvisMuted,
                                fontSize = 13.sp
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = JarvisCyan
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("command_input"),
                        singleLine = true
                    )

                    AnimatedVisibility(visible = textInput.isNotBlank()) {
                        IconButton(
                            onClick = {
                                val cmd = textInput.trim()
                                if (cmd.isNotEmpty()) {
                                    textInput = ""
                                    AutomationHelper.processCommand(context, cmd)
                                }
                            },
                            modifier = Modifier.testTag("send_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send",
                                tint = JarvisCyan
                            )
                        }
                    }

                    // Neon Glowing Mic Button
                    FloatingActionButton(
                        onClick = {
                            try {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to MYRA...")
                                }
                                speechInputLauncher.launch(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Voice input not available: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        containerColor = JarvisCyan,
                        contentColor = Color.Black,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(46.dp)
                            .then(if (isMicListening) Modifier.scale(pulseScale) else Modifier)
                            .testTag("mic_fab")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Speak to MYRA"
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChatMessageItem(message: ChatMessage) {
    val isUser = message.sender == MessageSender.USER
    val timeFormatted = remember(message.timestamp) {
        SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(message.timestamp))
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) Color(0xFF003840) else JarvisCardBg
            ),
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            border = if (!isUser) androidx.compose.foundation.BorderStroke(1.dp, JarvisCyan.copy(alpha = 0.25f)) else null,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .testTag("chat_bubble_${message.id}")
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                if (!isUser) {
                    Text(
                        text = "MYRA",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = JarvisCyan,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
                Text(
                    text = message.text,
                    color = Color.White,
                    fontSize = 14.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = timeFormatted,
                    fontSize = 9.sp,
                    color = JarvisMuted,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}
