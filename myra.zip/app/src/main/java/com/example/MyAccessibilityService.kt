package com.example

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MyAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "MyAccessibility"
        var instance: MyAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "MyAccessibilityService connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Can inspect active events if needed
    }

    override fun onInterrupt() {
        Log.d(TAG, "MyAccessibilityService interrupted")
    }

    fun clickSend() {
        val root = rootInActiveWindow ?: return
        try {
            val sendBtn = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send")
            if (!sendBtn.isNullOrEmpty()) {
                sendBtn[0].performAction(AccessibilityNodeInfo.ACTION_CLICK)
                Log.d(TAG, "Clicked WhatsApp send button by id")
                return
            }

            // Fallback find by text Send
            val list = root.findAccessibilityNodeInfosByText("Send")
            if (list.isNotEmpty()) {
                list[0].performAction(AccessibilityNodeInfo.ACTION_CLICK)
                Log.d(TAG, "Clicked send button by text")
                return
            }

            // Fallback find by contentDescription "Send"
            for (i in 0 until root.childCount) {
                val child = root.getChild(i)
                if (child?.contentDescription?.toString()?.equals("Send", ignoreCase = true) == true) {
                    child.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    Log.d(TAG, "Clicked send button by contentDescription")
                    return
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error clicking send: ${e.message}")
        }
    }

    fun getAllScreenText(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        fun traverse(node: AccessibilityNodeInfo?) {
            if (node == null) return
            if (node.text != null) {
                sb.append(node.text).append(" ")
            }
            for (i in 0 until node.childCount) {
                traverse(node.getChild(i))
            }
        }
        traverse(root)
        return sb.toString().trim()
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        Log.d(TAG, "MyAccessibilityService destroyed")
    }
}
