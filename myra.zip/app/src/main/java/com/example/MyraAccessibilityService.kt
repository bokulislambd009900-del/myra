package com.example

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class MyraAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "MyraAccessibility"
        var instance: MyraAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "MYRA Accessibility Service Connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        Log.d(TAG, "Accessibility Event from package: $pkg, type: ${event.eventType}")
    }

    override fun onInterrupt() {
        Log.d(TAG, "MYRA Accessibility Service Interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        Log.d(TAG, "MYRA Accessibility Service Destroyed")
    }
}
