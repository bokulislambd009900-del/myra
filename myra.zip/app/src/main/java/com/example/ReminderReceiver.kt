package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {
    companion object {
        private const val TAG = "ReminderReceiver"
        const val ACTION_REMINDER = "com.myra.jarvis.ACTION_REMINDER"
        const val EXTRA_TITLE = "extra_reminder_title"
        const val EXTRA_MESSAGE = "extra_reminder_message"
        private const val REMINDER_CHANNEL_ID = "MYRA_REMINDERS"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val text = intent.getStringExtra("text")
            ?: intent.getStringExtra(EXTRA_MESSAGE)
            ?: "Reminder"
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "MYRA Reminder"

        Log.d(TAG, "Reminder triggered: $text")

        // Speak reminder as requested
        TTSHelper.speak("Sir mone koriye dicchi: $text")
        AutomationHelper.addMessage(MessageSender.MYRA, "Sir mone koriye dicchi: $text")

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                REMINDER_CHANNEL_ID,
                "MYRA Reminders",
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, REMINDER_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        notificationManager.notify((System.currentTimeMillis() % 10000).toInt(), notification)
    }
}
