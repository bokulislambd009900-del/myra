package com.example

import android.content.Context
import android.os.Build
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

object TTSHelper : TextToSpeech.OnInitListener {
    private const val TAG = "TTSHelper"
    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var pendingSpeakText: String? = null

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    fun init(context: Context, onReady: (() -> Unit)? = null) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val engine = tts ?: return
            
            // Try Bengali first as requested, fallback to English if unavailable
            val bnLocale = Locale("bn", "BD")
            val langResult = engine.setLanguage(bnLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                engine.language = Locale.US
            }

            // Find best female voice
            try {
                val voices = engine.voices
                if (voices != null) {
                    val femaleVoice = voices.find { voice ->
                        val name = voice.name.lowercase(Locale.ROOT)
                        name.contains("female") || 
                        name.contains("woman") || 
                        name.contains("bengali") || 
                        voice.features?.any { it.contains("female", ignoreCase = true) } == true
                    }
                    if (femaleVoice != null) {
                        engine.voice = femaleVoice
                        Log.d(TAG, "Selected female voice: ${femaleVoice.name}")
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Could not set custom voice: ${e.message}")
            }

            // Pitch & Speech Rate as specified
            engine.setPitch(1.25f)
            engine.setSpeechRate(0.92f)

            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })

            isInitialized = true
            Log.d(TAG, "TTS initialized successfully with female voice settings")

            pendingSpeakText?.let {
                speak(it)
                pendingSpeakText = null
            }
        } else {
            Log.e(TAG, "TTS Initialization failed with status: $status")
        }
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        val engine = tts
        if (!isInitialized || engine == null) {
            pendingSpeakText = text
            return
        }
        val utteranceId = "myra_utterance_${System.currentTimeMillis()}"
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
        _isSpeaking.value = false
    }
}
