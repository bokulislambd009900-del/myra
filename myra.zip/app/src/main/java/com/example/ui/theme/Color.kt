package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val JarvisBlack = Color(0xFF080808)
val JarvisDarkSurface = Color(0xFF111319)
val JarvisCardBg = Color(0xFF161922)
val JarvisCyan = Color(0xFF00E5FF)
val JarvisCyanDark = Color(0xFF00B0FF)
val JarvisPurple = Color(0xFF7C4DFF)
val JarvisPurpleDark = Color(0xFF651FFF)
val JarvisTextCyan = Color(0xFFE0F7FA)
val JarvisMuted = Color(0xFF8090A0)
val JarvisGreen = Color(0xFF00E676)
val JarvisRed = Color(0xFFFF1744)
