package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JarvisColorScheme = darkColorScheme(
    primary = JarvisCyan,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF00363A),
    onPrimaryContainer = JarvisCyan,
    secondary = JarvisPurple,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF311B92),
    onSecondaryContainer = Color(0xFFD1C4E9),
    tertiary = JarvisCyanDark,
    background = JarvisBlack,
    onBackground = JarvisTextCyan,
    surface = JarvisDarkSurface,
    onSurface = JarvisTextCyan,
    surfaceVariant = JarvisCardBg,
    onSurfaceVariant = JarvisMuted,
    outline = JarvisCyan.copy(alpha = 0.4f)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false, // Keep consistent Jarvis neon theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        typography = Typography,
        content = content
    )
}
