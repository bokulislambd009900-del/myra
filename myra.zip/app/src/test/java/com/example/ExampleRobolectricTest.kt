package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("MYRA", appName)
  }

  @Test
  fun `verify automation app map entries`() {
    assertTrue(AutomationHelper.appMap.containsKey("youtube"))
    assertTrue(AutomationHelper.appMap.containsKey("whatsapp"))
    assertEquals("com.google.android.youtube", AutomationHelper.appMap["youtube"])
  }

  @Test
  fun `verify battery command parsing`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val response = AutomationHelper.processCommand(context, "battery koto")
    assertNotNull(response)
    assertTrue(response.contains("battery") || response.contains("Sir"))
  }

  @Test
  fun `verify ai manager key configured`() {
    assertTrue(AiManager.OPENAI_API_KEY.startsWith("sk-"))
    assertEquals("sk-TIjVHTw8cnElb5E6pi0WvIH7aROcScLTkZKjXGgnJbTkQfv1", AiManager.OPENAI_API_KEY)
  }
}
